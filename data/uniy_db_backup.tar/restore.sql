--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS uniy;
--
-- Name: uniy; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE uniy WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


\connect uniy

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_with_oids = false;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courses (
    course_id smallint NOT NULL,
    course_name character(20),
    department character(16),
    num_credits smallint
);


--
-- Name: enrolls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enrolls (
    course_id smallint NOT NULL,
    section_id smallint NOT NULL,
    student_id smallint NOT NULL,
    grade smallint
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    course_id smallint NOT NULL,
    section_id smallint NOT NULL,
    teacher_id smallint,
    num_students smallint
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    student_id smallint NOT NULL,
    student_name character(18),
    address character(20),
    city character(10),
    state character(2),
    zip character(5),
    gender character(1)
);


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teachers (
    teacher_id smallint NOT NULL,
    teacher_name character(18),
    phone character(10),
    salary numeric(10,2)
);


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3187.dat

--
-- Data for Name: enrolls; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3188.dat

--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3189.dat

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3190.dat

--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3191.dat

--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: enrolls enrolls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrolls
    ADD CONSTRAINT enrolls_pkey PRIMARY KEY (course_id, section_id, student_id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (course_id, section_id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (teacher_id);


--
-- Name: enrolls enrolls_fkey_course; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrolls
    ADD CONSTRAINT enrolls_fkey_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: enrolls enrolls_fkey_section; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrolls
    ADD CONSTRAINT enrolls_fkey_section FOREIGN KEY (course_id, section_id) REFERENCES public.sections(course_id, section_id) ON DELETE CASCADE;


--
-- Name: enrolls enrolls_fkey_student; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enrolls
    ADD CONSTRAINT enrolls_fkey_student FOREIGN KEY (student_id) REFERENCES public.students(student_id) ON DELETE CASCADE;


--
-- Name: sections sections_fkey_course; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_fkey_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: sections sections_fkey_teacher; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_fkey_teacher FOREIGN KEY (teacher_id) REFERENCES public.teachers(teacher_id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

